## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/web-services-rest-api-testing-with-soapui-and-real-time-projects-video/9781789134926)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Web-Services-REST-API-Testing-with-SoapUI-Real-Time-Projects
Code Repository for Web Services/REST API Testing with SoapUI+ Real Time Projects, Published by Packt
